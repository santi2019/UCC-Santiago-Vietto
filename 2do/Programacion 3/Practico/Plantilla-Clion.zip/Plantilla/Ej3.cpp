#include <iostream>

int min(int arr[], int size) {
    return -1;
}

int main() {
    int arreglo[] = {5, 9, 7, 8, 9, 3, 2, 1, 8}; // probar otros casos y valores.

    std::cout << "el valor menor es: " << min(arreglo, 9) << std::endl;
    return 0;
}
