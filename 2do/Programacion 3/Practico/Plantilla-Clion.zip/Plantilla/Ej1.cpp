/*
 * Ej1
 * Se pretende realizar un método en la lista enlazada que,
 * mediante un algoritmo, calcule la suma de los enteros
 * almacenados donde el valor sea superior a un valor
 * umbral que se pasará como parámetro al método.
 */

#include <iostream>
#include "Estructuras/Lista.h"

class ListaSuma : public Lista<int> {
public:
    int sumaDesde(int umbral) {
        return inicio->getDato() * umbral;
    }
};

int main() {
    ListaSuma miLista;

    miLista.insertarPrimero(6);
    miLista.insertarPrimero(2);
    miLista.insertarPrimero(5);
    miLista.insertarPrimero(3);
    miLista.insertarPrimero(4);

    miLista.print();

    std::cout << "Resultado: " << miLista.sumaDesde(3) << std::endl; // Debe dar 15
    return 0;
}
