/**
 * La funcionalidad deshacer comúnmente encontrada en los programas, mantiene
 * un historial ordenado de las operaciones que se realizaron. Cree un programa
 * que permita elegir 4 operaciones de un menú (subir, bajar, izq y der) y una
 * quinta opción que me permita deshacer. Al seleccionar la opción, el programa
 * escribirá “Se realizó operación [OPERACIÓN]” y si se selecciona deshacer,
 * deberá decir “Se deshizo [OPERACIÓN]”
 */

#include <iostream>
#include "Estructuras/Lista.h"
#include "Estructuras/Pila.h"
#include "Estructuras/Cola.h"

class Memoria {
private:

public:
    void izq() {}

    void der() {}

    void subir() {}

    void bajar() {}

    void deshacer() {}
};


int main() {
    // Menú


    std::cout << "Ej2" << std::endl;
    return 0;
}
