#include <iostream> //Librería para operaciones de entrada/salida
#include <stdlib.h> //El encabezado stdlib.h define cuatro tipos de variables, varias macros y varias funciones para realizar funciones generales.
#include <sstream>//Encabezado que proporciona clases de secuencia de strings.
#include <fstream> //Librería de flujo de entrada / salida para operar en archivos.
#include <vector> //Librería que contiene funciones para manejar vectores.
#include <algorithm> //Librería para usar la funcion sort.
#include <numeric> //Librería para usar la funcion iota, para almacenar secuencia creciente.
#include <string.h>
#include <stdio.h>

using namespace std;

constexpr unsigned int str2int(const char* str, int h = 0){
    return !str[h] ? 5381 : (str2int(str, h+1) * 33) ^ str[h];
}

//---------Función para obtener los datos desde el dataset, filtrarlos e insertarlos en una nueva tabla---------//
vector<vector<string>> abrirArchivos(string path) {

    ifstream csv;//Crea variable de tipo ifstream
    csv.open(path);//Abre el archivo en el directorio indicado por path
    if ( ! csv.is_open() ) {
        cout << " Falla en lectura del archivo. " << endl;
    }
    else {
        cout << " Lectura del archivo correcta. " << endl;
    }

    vector<vector<string>> nueva_tabla; //Creamos la tabla donde colocaremos los datos necesarios
    vector<string> row;
    string line, word;
    int index;

    while(getline(csv, line)){ //Leemos cada string del csv
        row.clear();
        stringstream lineStream(line); //Declaramos una variable de tipo stringstream, para poder extraer los strings (manipular la data)
        index = 0;
        while(getline(lineStream, word, ',')){ //Leemos cada palabra del dataset, separada por coma
            //2 = edad, 5 = nombre de provincia, 12 = SI o NO en cui, 14 = fallecido, 20 = clasificacion, 21 = idProvincia
            if(index == 2 || index == 5 || index == 12 || index == 13 || index == 14 || index == 20 || index == 21){ //Tomamos los índices de columnas que nos interesan
                if(word.size() > 0){ //Si existe alguna palabra
                    word = word.substr(1, word.size()-2 ); //La colocamos en la variable word sin las " "
                }else{
                    word = "null"; //Sino le asignamos "null", para que no quede vacía
                }
                row.push_back(word); //Insertamos las palabras en el vector row que corresponde a las filas de la nueva tabla
            }
            index++;
        }
        nueva_tabla.push_back(row);
    }
    return nueva_tabla;
}

//---------Función para obtener los datos generales de estadísticas---------//
void estad(vector<vector<string>> *nueva_tabla) {
    int contagiados = 0;
    int muertos = 0;
    int casos_totales = (*nueva_tabla).size()-1; //Tamanio hasta el index del last element.
    int i, j;

    for(i=1; i<(*nueva_tabla).size(); i++){ //Recorremos la nueva tabla segun su tamaño
        if((*nueva_tabla)[i][5] == "Confirmado")  //En la columna 5, comparamos si el valor de la fila es "Confirmado"
            contagiados++; //Sumo al contador de infectados
        if ((*nueva_tabla)[i][4] == "SI")//En la columna 4, comparamos si el valor de la fila es "SI"
            muertos++;//Sumo al contador fallecidos
    }
        
    cout << "Cantidad total de muestras: " << casos_totales << endl;
    cout << "Cantidad total de infectados: " << contagiados << endl;
    cout << "Cantidad total de fallecidos: " << muertos << endl;
    cout << "% infectados por muestras: " << ((float)contagiados/(float)casos_totales)*100 << "%" << endl;
    cout << "% de fallecidos por infectados: " << ((float)muertos/(float)contagiados)*100 << "%" << endl;

    vector<vector<string>> tmpnueva_tabla; //Genero una tabla temporal
    for(i=0; i<110; i=i+10){ //recorro por cada grupo etario, de 0 a 19 años
        tmpnueva_tabla.clear();
        contagiados = 0;
        muertos = 0;
        for(j=1; j<(*nueva_tabla).size(); j++){ //recorro toda la tabla original
            if((*nueva_tabla)[j][0] != "null"){ //si el valor encontrado no es nulo
                if(stoi((*nueva_tabla)[j][0]) >= i && stoi((*nueva_tabla)[j][0]) < i+10) //y cumple con las condiciones de que el valor este dentro del grupo etario
                    tmpnueva_tabla.push_back((*nueva_tabla)[j]); //agrego a la tabla temporal el valor en la tabla original
            }
        }
        for(j=1; j<tmpnueva_tabla.size(); j++){ //recorremos la tabla temporal segun su tamaño
            if(tmpnueva_tabla[j][5] == "Confirmado") //en la columna 5, comparamos si el valor de la fila es "Confirmado"
                contagiados++; //sumo al contador infectado
            if (tmpnueva_tabla[j][4] == "SI") //en la columna 4, comparamos si el valor de la fila es "SI"
                muertos++; //sumo al contador fallecido
        }
        cout << endl;
        cout << "Rango de edades: " << i << " a " << i+9 << " anios: " << endl;
        cout << "Cantidad de infectados: " << contagiados << endl;
        cout << "Cantidad de muertes:  " << muertos << endl;
    }
}

//---------Función para obtener los datos de los casos según la provincia---------//
void casosSegunProvincias(int n, vector<vector<string>> *nueva_tabla) {
    vector<string> provincias;
    provincias.clear();
    bool bandera; //Bandera para corroborar la presencia de Provincias en el vector
    for(int i=1; i<(*nueva_tabla).size(); i++){//Recorro la tabla
        if((*nueva_tabla)[i][1] != "null"){ //Si los valores no son null en la columna de nombre de la provincia
            if(provincias.empty()) //Y si el vector esta vacio nos devuelve un true
                provincias.push_back((*nueva_tabla)[i][1]); //Le pusheamos los datos de las provincias
            else{
                bandera = false; //Sino seteamos la bandera bandera como falsa
                for(int j=0; j<provincias.size(); j++){//Recorremos el vector
                    if(provincias[j] == (*nueva_tabla)[i][1]){ //y comparamos los valores de la tabla original y el vector
                        bandera = true;
                    }
                }
                if(!bandera)//Si el booleano es verdadero porque coincidieron los datos
                    provincias.push_back((*nueva_tabla)[i][1]);//Agregamos los datos de las provincias
            }

        }
    }

    vector<int> muertosTotales;
    muertosTotales.clear();
    int muertos = 0;
    for(int j=0; j<provincias.size(); j++){
        for(int i=1; i<(*nueva_tabla).size(); i++){//Recorro la tabla
            if((*nueva_tabla)[i][5] == "Confirmado"&& provincias[j] == (*nueva_tabla)[i][1]){
                muertos++;
            }
        }
        muertosTotales.push_back(muertos);
        muertos = 0;
    }

    std::vector<std::size_t> index (provincias.size());
    std::iota(index.begin(), index.end(), 0);
    std::sort(index.begin(), index.end(), [&](size_t a, size_t b) { return muertosTotales[a] > muertosTotales[b]; });

    if (n != false ){
        for (int i=index[0]-1; i<n; ++i){
            std::cout << provincias[i] << "\n";
        }
    }else{
        for(int i : index){
            std::cout << provincias[i] << "\n";
        }
    }
}

//---------Función para obtener los datos de las muertes según la provincia---------//
void muertesSegunProvincias(int n, vector<vector<string>> *nueva_tabla) {
    vector<string> provincias;
    provincias.clear();
    bool bandera;
    for(int i=1; i<(*nueva_tabla).size(); i++){
        if((*nueva_tabla)[i][1] != "null"){
            if(provincias.empty())
                provincias.push_back((*nueva_tabla)[i][1]);
            else{
                bandera = false;
                for(int j=0; j<provincias.size(); j++){
                    if(provincias[j] == (*nueva_tabla)[i][1]){
                        bandera = true;
                    }
                }
                if(!bandera)
                    provincias.push_back((*nueva_tabla)[i][1]);
            }
        }
    }

    vector<int> muertosTotales;
    muertosTotales.clear();
    int muertos = 0;
    for(int j=0; j<provincias.size(); j++){
        for(int i=1; i<(*nueva_tabla).size(); i++){
            if((*nueva_tabla)[i][4] == "SI" && provincias[j] == (*nueva_tabla)[i][1]){
                muertos++;
            }
        }
        muertosTotales.push_back(muertos);
        muertos = 0;
    }

    std::vector<std::size_t> index (provincias.size());
    std::iota(index.begin(), index.end(), 0);
    std::sort(index.begin(), index.end(), [&](size_t a, size_t b) { return muertosTotales[a] > muertosTotales[b]; });

    if (n != false ){
        for (int i=index[0]-1; i<n; ++i){
            std::cout << provincias[i] << "\n";
        }
    }else{
        for(int i : index){
            std::cout << provincias[i] << "\n";
        }
    }
}

void casos_cui(int f, vector<vector<string>> *nueva_tabla) {
    vector<string> fecha;
    vector<string> edad;
    vector<string> provincia;
    fecha.clear();
    bool found;
    for(int i=1; i<(*nueva_tabla).size(); i++){
        if((*nueva_tabla)[i][3] != "null"){ 
            if(fecha.empty()){ 
                fecha.push_back((*nueva_tabla)[i];}
            else{
                found = false; //sino seteamos la variable found coo falsa
                for(int j=0; j<fecha.size(); j++){//recorremos el vector
                    if(fecha[j] == (*nueva_tabla)[i][3]){ //y comparamos los valores de la tabla original y el vector
                        found = true;
                    }
                }
                if(!found)//si el booleano es verdadero porque coincidieron los datos
                    fecha.push_back((*nueva_tabla)[i][3]);//agregamos los datos de las ids provincias
            }
        }
    }

/*
vector<vector<string>> tmpnueva_tabla; 
    tmpnueva_tabla.clear();
    contagiados = 0;
     for(j=1; j<(*nueva_tabla).size(); j++){ 
        if((*nueva_tabla)[j][3] != "null"){ 
            if(stoi((*nueva_tabla)[j][0]) >= i && stoi((*nueva_tabla)[j][0]) < i+10) //y cumple con las condiciones de que el valor este dentro del grupo etario
                tmpnueva_tabla.push_back((*nueva_tabla)[j]); //agrego a la tabla temporal el valor en la tabla original
            }
        }
        for(j=1; j<tmpnueva_tabla.size(); j++){ //recorremos la tabla temporal segun su tamaño
            if(tmpnueva_tabla[j][5] == "Confirmado") //en la columna 5, comparamos si el valor de la fila es "Confirmado"
                contagiados++; //sumo al contador infectado
            if (tmpnueva_tabla[j][4] == "SI") //en la columna 4, comparamos si el valor de la fila es "SI"
                muertos++; //sumo al contador fallecido
        }
        cout << endl;
        cout << "Rango de edades: " << i << " a " << i+9 << " anios: " << endl;
        cout << "Cantidad de infectados: " << contagiados << endl;
        cout << "Cantidad de muertes:  " << muertos << endl;
    }
}*/

for(int i = 0; i < fecha.size(); i++){
    cout << fecha[i] <<endl;
}


}

//
// Created by Aye on 11/22/2020.
//

#ifndef UNTITLED3_PARCIAL_H
#define UNTITLED3_PARCIAL_H

#endif //UNTITLED3_PARCIAL_H
