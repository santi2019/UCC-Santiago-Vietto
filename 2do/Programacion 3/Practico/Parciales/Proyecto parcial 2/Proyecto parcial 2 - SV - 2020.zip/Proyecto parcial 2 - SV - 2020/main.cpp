#include "./parcial.h"

int main(int argc, char **argv) {

    string path = "./Covid19Casos-100000.csv";
    vector<vector<string>> nueva_tabla = abrirArchivos(path);

    for (int i = 1; i < argc; i++) {
        switch (str2int(argv[i])){
            case str2int("-estad"):
                estad(&nueva_tabla);
                break;
            case str2int("-p_casos"):
                casosSegunProvincias(atoi(argv[i + 1]), &nueva_tabla);
                break;
            case str2int("-p_muertes"):
                muertesSegunProvincias(atoi(argv[i + 1]), &nueva_tabla);
                break;
            /*case str2int ("-casosSegunEdad"):
                casosSegunEdad(atoi(argv[i + 1]), &nueva_tabla);
                break; */
            case str2int ("-casos_cui"):
                casos_cui(atoi(argv[i + 1]), &nueva_tabla);
                break;
            default:
                break;
        }
    }

    return 0;
}