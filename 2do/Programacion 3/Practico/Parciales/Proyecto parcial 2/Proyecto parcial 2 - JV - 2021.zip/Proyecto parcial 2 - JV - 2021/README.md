# TrabajoProgramacion_Aquilino-Rojo-Vietto

## Autores: 
* Octavio  **Aquilino**
* Nicolás  **Rojo** 
* Joaquín **Vietto**

## Contacto:
|Email Institucional|Autores|
|---------|---------|
|2008893@ucc.edu.ar|Octavio Aquilino|
|2000262@ucc.edu.ar|Nicolás Rojo|
|2006111@ucc.edu.ar|Joaquí VIetto|


## Tecnologías usadas:
* C++
