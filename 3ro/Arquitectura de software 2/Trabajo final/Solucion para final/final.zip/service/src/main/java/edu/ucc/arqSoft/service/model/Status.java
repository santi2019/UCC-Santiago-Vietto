package edu.ucc.arqSoft.service.model;

public enum Status {
	APAGADO, ENCENDIDO;
}