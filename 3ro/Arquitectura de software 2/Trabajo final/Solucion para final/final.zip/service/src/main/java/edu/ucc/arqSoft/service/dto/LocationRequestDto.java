package edu.ucc.arqSoft.service.dto;

public class LocationRequestDto {
	
	private String Name;
	
	public String getName() {
		return Name;
	}
	
	public void setName(String name) {
		this.Name = name;
	}

}
