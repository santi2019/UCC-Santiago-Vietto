package edu.ucc.arqSoft.service.dto;

public class LocationResponseDto {
	
	private Long id;
	
	private String Name;
	
	public Long getid() {
		return id;
	}
	
	public String getName() {
		return Name;
	}
	
	public void setName(String name) {
		this.Name = name;
	}
}
