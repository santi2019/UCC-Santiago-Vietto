-- You can use this file to load seed data into the database using SQL statements
 insert into SOCIO (NOMBRE, APELLIDO, EMAIL, DNI) values ('Edu', 'Gaite', 'edu@gmail.com', '11111111');
