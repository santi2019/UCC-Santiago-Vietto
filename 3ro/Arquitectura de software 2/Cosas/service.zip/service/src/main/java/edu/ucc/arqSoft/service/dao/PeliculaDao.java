package edu.ucc.arqSoft.service.dao;

import edu.ucc.arqSoft.service.common.dao.GenericDao;
import edu.ucc.arqSoft.service.model.Pelicula;

public interface PeliculaDao extends GenericDao<Pelicula, Long>{

}
