package edu.ucc.arqSoft.service.dao;

import edu.ucc.arqSoft.service.common.dao.GenericDao;
import edu.ucc.arqSoft.service.model.Alquiler;

public interface AlquilerDao extends GenericDao<Alquiler, Long>{

}
