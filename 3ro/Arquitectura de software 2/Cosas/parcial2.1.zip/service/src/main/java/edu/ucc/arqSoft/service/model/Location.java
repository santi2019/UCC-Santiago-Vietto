package edu.ucc.arqSoft.service.model;

public enum Location {
	JUJUY, MENDOZA, CORDOBA, SANTACRUZ, MISIONES;
}
