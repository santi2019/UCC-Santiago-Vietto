package edu.ucc.arqSoft.service.model;

public enum Genero {
	TERROR, COMEDIA, DRAMA,DOCUMENTAL;
}
